from __future__ import print_function
print("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent metus.")
